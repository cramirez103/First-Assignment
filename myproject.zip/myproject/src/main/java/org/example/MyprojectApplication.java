package org.example; // Corrected package name

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller; // Import Controller for web handling
import org.springframework.ui.Model; // Import Model to pass data to HTML templates
import org.springframework.web.bind.annotation.GetMapping; // For handling GET requests
import org.springframework.web.bind.annotation.ModelAttribute; // For binding form data
import org.springframework.web.bind.annotation.PostMapping; // For handling POST requests
import org.springframework.web.servlet.mvc.support.RedirectAttributes; // For flash attributes

/**
 * Christopher Ramirez
 * COP 3330 Project 8: Greeting
 * Date: July 20, 2025
 *
 * Program Objective: This Spring Boot application creates a web interface
 * for users to input their student ID, a date (month, day, year), and a message.
 * It validates the entered date and displays all submitted information on a
 * separate results page if the date is valid. Otherwise, it displays an error.
 *
 * Inputs supplied by the user:
 * - Student ID (String)
 * - Month (Integer)
 * - Day (Integer)
 * - Year (Integer)
 * - Message (String)
 *
 * Outputs printed on the screen (web browser):
 * - Initial Greeting form with input fields and specific header/message formatting.
 * - Results page displaying all entered data with specific header/message formatting
 * and the date formatted as MM/DD/YYYY.
 * - Error message on the Greeting form if an invalid date is entered.
 */
@SpringBootApplication // Marks this as a Spring Boot application entry point
@Controller // Marks this class as a Spring MVC controller to handle web requests
public class MyprojectApplication {

    /**
     * Main method to start the Spring Boot application.
     * @param args Command-line arguments passed to the application.
     */
    public static void main(String[] args) {
        SpringApplication.run(MyprojectApplication.class, args);
    }

    /**
     * Handles GET requests to the root URL ("/").
     * Displays the greeting form.
     * @param model Model object to pass data (like pre-filled form data or error messages) to the view.
     * @param formData ModelAttribute to bind existing form data (e.g., after an error redirect).
     * @return The name of the Thymeleaf template ("greeting.html") to render.
     */
    @GetMapping("/")
    public String showGreetingForm(Model model, @ModelAttribute("formData") FormData formData) {
        // If there's an error message from a redirect, it will be in the model.
        // If formData is null (first load or no data from redirect), initialize it to avoid NullPointerException in Thymeleaf.
        if (formData == null || formData.getStudentId() == null) {
            model.addAttribute("formData", new FormData()); // Create a new empty FormData object
        } else {
            // If redirected with formData (e.g., after an invalid date), add it back to the model explicitly
            model.addAttribute("formData", formData);
        }
        return "greeting"; // Renders src/main/resources/templates/greeting.html
    }

    /**
     * Handles POST requests to "/submit" when the form is submitted.
     * Processes the user's input, validates the date, and redirects to the results page
     * or back to the greeting form with an error.
     * @param formData An object containing the data submitted from the form.
     * @param redirectAttributes Used to add flash attributes (data that survives a redirect).
     * @return A redirect URL, either to the results page or back to the greeting form.
     */
    @PostMapping("/submit")
    public String processForm(@ModelAttribute FormData formData, RedirectAttributes redirectAttributes) {
        // Validate the date entered by the user using the isValidDate method in FormData
        if (!formData.isValidDate()) {
            // If the date is invalid, add an error message to be displayed on the greeting form
            redirectAttributes.addFlashAttribute("errorMessage", "Error: Invalid date entered. Please use a valid month, day, and year.");
            // Add the original form data as a flash attribute so it can be pre-filled on redirect
            redirectAttributes.addFlashAttribute("formData", formData);
            return "redirect:/"; // Redirect back to the greeting form
        }

        // If the date is valid, add the form data to the model for the results page
        redirectAttributes.addFlashAttribute("formData", formData);
        return "redirect:/results"; // Redirect to the results page
    }

    /**
     * Handles GET requests to "/results".
     * Displays the results page with the submitted data.
     * @param model Model object to pass data to the HTML template.
     * @param formData ModelAttribute to retrieve the form data passed as a flash attribute.
     * @return The name of the Thymeleaf template ("results.html") to render.
     */
    @GetMapping("/results")
    public String showResults(@ModelAttribute("formData") FormData formData, Model model) {
        // Check if formData is available (it should be from the redirect if coming from /submit)
        // If direct access to /results without form submission, formData might be empty.
        if (formData == null || formData.getStudentId() == null) {
            // If formData is not properly populated (e.g., direct access), redirect to the form.
            return "redirect:/";
        }
        model.addAttribute("formData", formData); // Add formData to the model for the Thymeleaf template
        return "results"; // Renders src/main/resources/templates/results.html
    }
}