package org.example; // Corrected package name

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 * Christopher Ramirez
 * COP 3330 Project 8: Greeting
 * Date: July 20, 2025
 *
 * Program Objective: This class serves as a data model to hold the input
 * from the web form, including student ID, date components (month, day, year),
 * and a message. It also provides methods for date validation and formatting.
 *
 * Inputs: Student ID (String), Month (Integer), Day (Integer), Year (Integer),
 * Message (String) - all supplied by the user via a web form.
 * Outputs: Formatted date (String) or validation error messages.
 */
public class FormData {

    private String studentId;
    private Integer month;
    private Integer day;
    private Integer year;
    private String message;
    private String formattedDate; // To store the date in MM/DD/YYYY format

    // --- Getters and Setters ---
    // These methods allow access to and modification of the private fields.

    /**
     * Retrieves the student ID.
     * @return The student ID as a String.
     */
    public String getStudentId() {
        return studentId;
    }

    /**
     * Sets the student ID.
     * @param studentId The student ID to set.
     */
    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    /**
     * Retrieves the month component of the date.
     * @return The month as an Integer.
     */
    public Integer getMonth() {
        return month;
    }

    /**
     * Sets the month component of the date.
     * @param month The month to set.
     */
    public void setMonth(Integer month) {
        this.month = month;
    }

    /**
     * Retrieves the day component of the date.
     * @return The day as an Integer.
     */
    public Integer getDay() {
        return day;
    }

    /**
     * Sets the day component of the date.
     * @param day The day to set.
     */
    public void setDay(Integer day) {
        this.day = day;
    }

    /**
     * Retrieves the year component of the date.
     * @return The year as an Integer.
     */
    public Integer getYear() {
        return year;
    }

    /**
     * Sets the year component of the date.
     * @param year The year to set.
     */
    public void setYear(Integer year) {
        this.year = year;
    }

    /**
     * Retrieves the user's message.
     * @return The message as a String.
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the user's message.
     * @param message The message to set.
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * Retrieves the formatted date (MM/DD/YYYY).
     * @return The formatted date as a String.
     */
    public String getFormattedDate() {
        return formattedDate;
    }

    /**
     * Sets the formatted date.
     * @param formattedDate The formatted date string to set.
     */
    public void setFormattedDate(String formattedDate) {
        this.formattedDate = formattedDate;
    }

    /**
     * Validates if the month, day, and year form a valid date.
     * If valid, it also sets the formattedDate field.
     * @return true if the date is valid, false otherwise.
     */
    public boolean isValidDate() {
        // Check if any date component is null, which would make it invalid for LocalDate.of
        if (month == null || day == null || year == null) {
            return false;
        }
        try {
            // Attempt to create a LocalDate object from the provided components.
            // This will throw a DateTimeParseException if the date is invalid (e.g., Feb 30).
            LocalDate date = LocalDate.of(year, month, day);

            // If successful, format the date as MM/DD/YYYY and store it.
            // %02d ensures two digits with leading zero for month/day
            // %04d ensures four digits for year
            this.formattedDate = String.format("%02d/%02d/%04d", month, day, year);
            return true;
        } catch (DateTimeParseException e) {
            // Catch the exception if the date is invalid.
            return false;
        }
    }
}